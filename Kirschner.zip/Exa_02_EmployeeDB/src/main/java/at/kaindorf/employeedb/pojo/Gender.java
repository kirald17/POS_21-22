package at.kaindorf.employeedb.pojo;

public enum Gender {
    M,F;
}
