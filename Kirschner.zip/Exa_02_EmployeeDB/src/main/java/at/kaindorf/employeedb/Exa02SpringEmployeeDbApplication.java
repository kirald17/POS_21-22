package at.kaindorf.employeedb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exa02SpringEmployeeDbApplication {

    public static void main(String[] args) {
        SpringApplication.run(Exa02SpringEmployeeDbApplication.class, args);
    }

}
