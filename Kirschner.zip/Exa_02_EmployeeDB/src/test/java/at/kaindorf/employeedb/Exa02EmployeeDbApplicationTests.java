package at.kaindorf.employeedb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exa02EmployeeDbApplicationTests {

    @Test
    void contextLoads() {
    }

}
